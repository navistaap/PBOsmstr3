/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum6_tugas;

/**
 *
 * @author hp_5c
 */
public class Main {
    public static void main(String[] args) {
        KeranjangBelanja keranjang = new KeranjangBelanja();

        // Tambah produk
        keranjang.tambahProduk(new Buku("Pemrograman Java", 100000));
        keranjang.tambahProduk(new Elektronik("Smartphone", 3000000));
        keranjang.tambahProduk(new Pakaian("Jaket", 250000));

        // Tampilkan detail produk
        keranjang.tampilkanProduk();

        // Total bayar
        System.out.println("-------------------------");
        System.out.println("Total Bayar: " + keranjang.hitungTotal());
    }
}

